--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) UNSIGNED NOT NULL,
  `comment` text NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `posted_at` int(11) NOT NULL,
  `post_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `user_id`, `posted_at`, `post_id`) VALUES
(1, 'Hello', 2, 2147483647, 2),
(2, 'Hello', 2, 2147483647, 2),
(3, 'How are you?', 2, 2147483647, 1),
(4, 'Test', 2, 2147483647, 2),
(5, 'What is happening', 2, 2147483647, 2),
(6, 'jdsaojdoasjda', 2, 2147483647, 2),
(7, 'Hello', 1, 2147483647, 2),
(8, 'hi', 1, 2147483647, 2),
(9, 'no', 1, 2147483647, 2),
(10, 'hi', 1, 2147483647, 1),
(11, 'hi', 1, 2147483647, 2),
(12, 'heihifuw', 1, 2147483647, 2),
(13, 'hello', 1, 2147483647, 2),
(14, 'hello', 1, 2147483647, 1),
(15, 'whatsaaaapp', 1, 2147483647, 1),
(16, 'a', 1, 2147483647, 1),
(17, '<b>hello<b>', 1, 2147483647, 1),
(18, 'a', 1, 2147483647, 1),
(19, 'b', 1, 2147483647, 1),
(20, 'as', 1, 2147483647, 1),
(21, 'hello', 1, 2147483647, 1),
(22, 'ola', 1, 2147483647, 1),
(23, 'coz', 1, 2147483647, 1),
(24, '</b>hi', 1, 2147483647, 1),
(25, 'no', 1, 2147483647, 1),
(26, '<b>no</b>', 1, 2147483647, 1),
(27, 'Hello', 1, 2147483647, 3),
(28, 'Hello', 1, 2147483647, 1),
(29, 'HI', 2, 2147483647, 6),
(30, 'hi\r\n', 2, 2147483647, 6),
(31, 'yo', 2, 2147483647, 1),
(32, 'yo', 2, 2147483647, 1),
(33, 'as', 1, 2147483647, 9),
(34, 'hello', 1, 2147483647, 9),
(35, 'hello', 1, 2147483647, 5),
(36, 'Hello', 1, 2147483647, 5),
(37, 'How are you?', 1, 2147483647, 5),
(38, 'YO', 1, 2147483647, 5),
(39, 'hello', 2, 2147483647, 10),
(40, 'Hello', 1, 2147483647, 10),
(41, 'Great plan!', 1, 2147483647, 10),
(42, 'Hello', 1, 2147483647, 16),
(43, 'HI', 1, 2147483647, 10);

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `follower_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`id`, `user_id`, `follower_id`) VALUES
(18, 1, 2),
(19, 4, 2),
(20, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_tokens`
--

CREATE TABLE `login_tokens` (
  `id` int(11) UNSIGNED NOT NULL,
  `token` char(64) NOT NULL DEFAULT '',
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_tokens`
--

INSERT INTO `login_tokens` (`id`, `token`, `user_id`) VALUES
(25, '3554ef2cdc87a7371b41d53398da3588dc2c97f3', 6),
(36, '7f1a39ae0a3f4f24e03dd7fbef03627a7c38c160', 4),
(47, '33b4e2b85c5229a8682df6275c654627a7d827d3', 2);

-- --------------------------------------------------------

--
-- Table structure for table `mealplan`
--

CREATE TABLE `mealplan` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(55) NOT NULL,
  `recipe1` varchar(80) NOT NULL,
  `ingredient1` text NOT NULL,
  `instruction1` text NOT NULL,
  `recipe2` varchar(80) NOT NULL,
  `ingredient2` text NOT NULL,
  `instruction2` text NOT NULL,
  `recipe3` varchar(80) NOT NULL,
  `ingredient3` text NOT NULL,
  `instruction3` text NOT NULL,
  `recipe4` varchar(80) NOT NULL,
  `ingredient4` text NOT NULL,
  `instruction4` text NOT NULL,
  `recipe5` varchar(80) NOT NULL,
  `ingredient5` text NOT NULL,
  `instruction5` text NOT NULL,
  `posted_at` datetime NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `likes` int(11) UNSIGNED NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mealplan`
--

INSERT INTO `mealplan` (`id`, `title`, `recipe1`, `ingredient1`, `instruction1`, `recipe2`, `ingredient2`, `instruction2`, `recipe3`, `ingredient3`, `instruction3`, `recipe4`, `ingredient4`, `instruction4`, `recipe5`, `ingredient5`, `instruction5`, `posted_at`, `user_id`, `likes`, `description`) VALUES
(10, 'Vegetarian plan', 'Wilted spinach with yoghurt & raisins', '    300 g frozen spinach , (or 800g fresh spinach)\r\n    1 small clove of garlic\r\n    500 g Greek yoghurt\r\n    sunflower oil\r\n    40 g raisins\r\n    extra virgin olive oil\r\n\r\n', '\r\n\r\n    Place the spinach in a saucepan with a few tablespoons of water and cook over a medium heat for a few minutes, or until defrosted (if using frozen) and just cooked. Take off the heat and leave to cool.\r\n    Peel and crush the garlic and mix with the yoghurt, ¾ of a teaspoon of sea salt and a generous grind of black pepper. Stir in the cooled spinach.\r\n    Heat 1 tablespoon of sunflower oil in a small pan and fry the raisins for 1 to 2 minutes, or until starting to plump up.\r\n    Scatter over the spinach and finish with a drizzle of extra virgin olive oil just before serving.\r\n\r\n', 'Aubergine parmigiana with crispy breadcrumbs', '\r\n\r\n    2 small courgettes\r\n    1 small aubergine\r\n    1 bunch of fresh basil , 15g\r\n    1 clove of garlic\r\n    olive oil\r\n    1 x 400 g tin of tomatoes\r\n    75 g mozzarella cheese\r\n    50 g dried breadcrumbs\r\n    10 g Parmesan cheese\r\n    1 lemon\r\n    extra virgin olive oil\r\n    50 g rocket\r\n\r\n', '\r\n\r\n    Preheat the grill to full whack and place a large tray on a shelf close to the heat.\r\n    Trim the courgettes and aubergine, slice lengthways into ½ cm pieces, then place in a bowl. Sprinkle generously with sea salt and toss, then put aside.\r\n    Pick the basil leaves, set aside and finely chop the stalks. Peel and finely chop the garlic.\r\n    Heat ½ tablespoon of olive oil in a medium saucepan over a medium heat, add the garlic and basil stalks, then fry gently for 2 minutes before adding half the tomatoes (save the rest of another day) and the same volume of water. Cook for 10 minutes, or until it reaches a saucy consistency.\r\n    Meanwhile, rinse the courgette and aubergine, then pat dry with kitchen roll. Tip back into a bowl and toss with 1 ½ tablespoons of olive oil, and a good pinch of seasoning.\r\n    Spread the courgette and aubergine on the hot tray and slide under the heat (you may need to do this in batches, as you want the veg in one layer).\r\n    Grill for 5 minutes, or until browned, then flip the veg grill for a further 5 minutes. Keep an eye on the veg as it grills, then tip into a bowl.\r\n    Taste and season the sauce, then pour over the vegetables. Tear over the basil leaves and mix.\r\n    Spread evenly on the tray and tear over the mozzarella. Sprinkle with breadcrumbs and grate over the Parmesan, then slide back under the grill. Grill until the cheese has melted.\r\n    Meanwhile, squeeze half the lemon juice into a bowl, add 1 tablespoon of extra virgin olive oil and pinch of seasoning. Mix well, then toss through the rocket. When the parmigiana is bubbling and delicious, divide between plates and serve with the rocket.\r\n\r\n', 'John Bishop''s ultimate veggie lasagne', ' 2 onion squash , (850g in total)\r\nolive oil\r\n1 teaspoon fennel seeds\r\ndried chilli flakes , (optional)\r\n60 g Parmesan cheese , (or vegetarian hard cheese)\r\n100 g Cheddar cheese\r\n100 g baby spinach\r\n350 g fresh lasagne sheets\r\n100 g ripe mixed-colour cherry tomatoes \r\n WHITE SAUCE\r\n20 g dried porcini\r\n4 cloves of garlic\r\n250 g mixed mushrooms\r\n1 sprig fresh rosemary\r\n2 sprigs fresh thyme\r\n500 ml crème fraîche\r\n50 g Parmesan , (or vegetarian hard cheese)\r\nVEG RAGÙ\r\n2 onions\r\n2 carrots\r\n2 sticks of celery\r\na few sprigs each of fresh thyme, rosemary, sage\r\n2 fresh bay leaves\r\n100 ml Barolo\r\n2 x 400 g tins of quality plum tomatoes\r\n2 x 400 g tins of tins of beans such as cannellini, borlotti, haricot\r\n1 large aubergine , (600g)\r\nPESTO\r\n1 big bunch of fresh basil , (60g)\r\na few sprigs each of fresh soft herbs, such as mint, oregano, parsley\r\n100 g Parmesan , (or vegetarian hard cheese)\r\n½ a clove of fresh garlic\r\n100 g pine nuts, almonds, walnuts\r\nextra virgin olive oil\r\n½ a lemon ', '\r\n\r\n    Preheat the oven to 180ºC/350ºF/gas 4.\r\n    For the base of your white sauce, just cover the dried porcini with boiling kettle water and leave to rehydrate.\r\n    Halve the squash, scoop out, wash and reserve the seeds. Drain and pat dry, then place onto a tray, drizzle with oil, scatter with the fennel seeds, a good pinch of chilli flakes (if using), and sea salt and black pepper.\r\n    Roughly chop each squash into 8 chunky wedges, then toss on a large tray with a little olive oil, salt, pepper and a good pinch of chilli flakes. Roast for 1 hour, or until golden, adding the tray of seeds for the last 30 minutes.\r\n    For the ragù, peel the onion and carrots, trim the celery, then chop it all into 1cm dice and place in a large casserole pan with 2 tablespoon of olive oil. Cook on a medium heat for 20 minutes, or until softened, stirring occasionally.\r\n    Tie the herb sprigs together with string to make a bouquet garni, add to the pan for a few minutes, then pour in the wine and leave to bubble and cook away.\r\n    Tip in the tomatoes, breaking them up with the back of a wooden spoon, then pour in 2 tins’ worth of water. Leave to tick away for 30 minutes, then drain and add the beans. Cook for a further 30 minutes, or until thickened and reduced, stirring and mashing occasionally with a potato masher, and adding splashes of water to loosen, if needed. Season to perfection.\r\n    Meanwhile, place the aubergine directly over a flame on the hob, turning regularly with tongs until softened and blackened all over. Place in a bowl, cover with clingfilm and leave for 5 minutes. When the time’s up, remove the clingfilm, pour the juices into the pan, then halve the aubergine and scrape out all the flesh, discarding the seeds, then stir into the pan.\r\n    For the white sauce, peel and finely slice the garlic, and clean and finely slice the mushrooms. Pick and finely chop the herbs.\r\n    Heat 2 tablespoons of olive oil in a pan, add the garlic for 1 minute, then add the herbs, mushrooms and a pinch of salt and pepper, then cook until just starting to colour, stirring regularly.\r\n    Add the porcini and soaking liquor (leaving any gritty bits behind), leave to bubble and cook away, then turn the heat down to low, stir in the crème fraîche and cook gently for a few minutes. Remove from the heat, finely grate and stir in the veggie friendly Parmesan.\r\n    To assemble the lasagne, grate the Cheddar and the Parmesan. Remove the bouquet garni from the ragù, stir in the Parmesan, then generously spoon 2 ladlefuls into the bottom of a 25cm x 30cm lasagne dish. Drizzle over 2 tablespoons of white sauce, tear over a quarter of the squash, scatter over a handful of spinach, and top with a layer of pasta. Repeat 3 further times, finishing with the remaining creamy sauce.\r\n    Using a spatula, loosen the edges (this will push some of the sauce down the sides for bonus flavour!), then top with the grated Cheddar.\r\n    Slice up the tomatoes, quickly toss in olive oil, dot over the top, then bake in the oven for 45 minutes, or until golden and bubbling.\r\n    For the pesto, rip the top leafy half of the herbs into a food processor. Break in the Parmesan, finely slice and add the garlic and tip in the pine nuts and/or nuts, season with a pinch of salt and pepper. Whiz until very finely chopped, then stir through 8 tablespoons of extra virgin olive oil and the lemon juice. Taste and tweak to your liking (this makes more than you need, so freeze any leftovers for another day).\r\n    Once cooked, remove the lasagne from the oven and leave to stand for 30 minutes. Serve with the pesto on the side for drizzling on top, crispy seeds for scattering over, and a fresh, seasonal salad.\r\n\r\n', 'Middle Eastern roasted sprouts', '\r\n\r\n    500 g Brussels sprouts\r\n    1 teaspoon cumin seeds\r\n    2 teaspoons coriander seeds\r\n    2 small red onions\r\n    1 bulb of fennel\r\n    olive oil\r\n    1 teaspoon sesame seeds\r\n    25 g hazelnuts\r\n    200 g Greek yoghurt\r\n    1 heaped teaspoon tahini\r\n    1 small clove of garlic\r\n    1 lemon\r\n    1 pinch of sumac\r\n    ½ a bunch of fresh coriander, dill and mint (20g)\r\n\r\n', '\r\n\r\n    Preheat the oven to 200ºC/400ºF/gas 6.\r\n    Bring a large pan of salted water to the boil over a medium-high heat. Wash and trim the sprouts, then add to the pan and parboil for 3 minutes. Drain in a colander and set aside to dry.\r\n    Toast the cumin and coriander seeds in a small frying pan over a medium heat for 3 minutes, or until fragrant. Using a pestle and mortar, finely grind the toasted seeds with a pinch of sea salt.\r\n    Tip most of the spice mix into a large roasting tray and toss in the sprouts.\r\n    Peel and slice the onions, then trim and slice the fennel. Tip into the tray along with a glug of oil.\r\n    Spread everything in an even layer – you may need two trays – and cook for 20 minutes, until tender and starting to caramelise.\r\n    Meanwhile, return your frying pan to the heat and toast the sesame seeds and hazelnuts for 3 minutes, then grind up with the remaining spices, using a pestle and mortar.\r\n    Combine the yoghurt with the tahini. Peel and crush the garlic and stir through, then finely grate in half the lemon zest and squeeze in half the juice (save the rest for another day).\r\n    Taste the yoghurt and season well, then spread it evenly over the base of a large serving platter and sprinkle some sumac over the top.\r\n    Spoon the sprout mix on top of the yoghurt mixture, scraping up the lovely crispy bits in the pan. Sprinkle the ground nuts and seeds over the top.\r\n    Pick and finely chop the herb leaves, discarding the stalks. Scatter the leaves across the plate, then serve.\r\n\r\n', 'Baked squash', '\r\n\r\n    1 butternut squash , (1.2kg)\r\n    olive oil\r\n    1 red onion\r\n    1 clove of garlic\r\n    1 bunch of fresh sage , (30g)\r\n    10 sun-dried tomatoes\r\n    75 g vac-packed chestnuts\r\n    75 g basmati rice\r\n    75 g dried cranberries\r\n    1 pinch of ground allspice\r\n    red wine\r\n\r\n', 'Preheat the oven to 180°C/350°F/gas 4. Wash the squash, carefully cut it in half lengthways, then remove and reserve the seeds. Use a spoon to score and scoop some flesh out, making a gully for the stuffing all along the length of the squash. Finely chop the scooped-out flesh with the seeds and put into a frying pan on a medium heat with 2 tablespoons of oil. Peel, finely chop and add the onion and garlic, stirring regularly while you pick the sage leaves and finely chop them with the sun-dried tomatoes and chestnuts. Stir into the pan with the rice, cranberries and allspice, add a good pinch of sea salt and black pepper and a swig of red wine, and mix well. Fry for 10 minutes, or until softened, stirring occasionally.\r\n\r\nPack the mixture tightly into the gully in the two squash halves, then press the halves firmly back together. Rub the skin of the squash with a little oil, salt and pepper, and if you’ve got them, pat on any extra herb leaves you have to hand. Place the squash in the centre of a double layer of tin foil, then tightly wrap it up. Bake for around 2 hours, or until soft and cooked through.\r\n\r\nOnce ready, take the squash to the table and open up the foil in front of everyone, then carve into nice thick slices and serve with all the usual trimmings.', '2017-04-25 23:39:10', 1, 0, 'A vegeterian meal plan that should be done for at least 3 days'),
(11, 'hello', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2017-05-05 22:18:36', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) UNSIGNED NOT NULL,
  `type` int(11) UNSIGNED NOT NULL,
  `receiver` int(10) UNSIGNED NOT NULL,
  `sender` int(11) UNSIGNED NOT NULL,
  `time` datetime NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `receiver`, `sender`, `time`, `post_id`) VALUES
(25, 2, 4, 2, '2017-05-01 02:07:40', 12),
(26, 2, 1, 2, '2017-05-01 20:28:48', 11),
(27, 2, 1, 1, '2017-05-01 20:32:02', 16),
(28, 1, 1, 1, '2017-05-01 20:33:09', 16),
(29, 1, 1, 2, '2017-05-02 21:48:58', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_tokens`
--

CREATE TABLE `password_tokens` (
  `id` int(11) UNSIGNED NOT NULL,
  `token` char(64) NOT NULL DEFAULT '',
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `id` int(11) UNSIGNED NOT NULL,
  `post_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `email` text,
  `profileimg` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `profileimg`) VALUES
(1, 'zazza96', '$2y$10$jkBTpFbS0Q0eTeHuAbkEOOCKpaSLAy0YbFFLZ8dMFWVQkwUMjJrXy', 'zazza96@gmail.com', 'http://i.imgur.com/KL28M7G.jpg'),
(2, 'zahid1', '$2y$10$uss6Y5EHduZACCj5Bk.O9eBA8K.nCRGCsuI1JOhCu7GkMXIzPivtq', 'zahid1@ncl.com', 'http://i.imgur.com/v9dcvqc.jpg'),
(3, 'newuser', '$2y$10$TcJ5OMtlb/RxmGroQcTjG.HQaZ/KN/vxwhvRovTV0DoUBn.k1qgru', 'user@mail.com', ''),
(4, 'user1test', '$2y$10$lPm.mTtdQTYBhbJIjAuC3.GJToxlCy/J7tlTf5pZtNW3oaSEBW97K', 'mail@mail.co.uk', 'http://i.imgur.com/ClOuGSe.png'),
(5, 'LUKAKU', '$2y$10$zPBPzExLDXu/imoYOMMxb.mSkooJfRbKsRTcjTxpbavR5l.Eq5Cky', 'romelu@gmail.com', 'http://i.imgur.com/ClOuGSe.png'),
(6, 'Mark', '$2y$10$mL22kAI3SjNERG.MRtRSYuxDvDasjI8OGiVhcaqoWDngRzNdaI1N6', 'mail@mail.com', 'http://i.imgur.com/ClOuGSe.png'),
(8, 'zahidhossain', '$2y$10$rZiupNIO.vA6O36OihrFSeCyF.0urVYH0fZNmDhayOyQlqzfidpqe', 'zahid.hossain@hotmail.com', 'http://i.imgur.com/ClOuGSe.png'),
(9, 'zeee', '$2y$10$o1bEjx1CRcxOr.Jo4CbIeu6N/vmEs.fQ1bCJXT602XOdH0nsxPQcm', 'b.zihady@outlook.com', 'http://i.imgur.com/ClOuGSe.png'),
(10, 'zahid', '$2y$10$NFxDcd5Oqubzm35L1o6ZUO5dAk/EBOly2CEaXsytC/Brk5SMG.ZIK', 'asdhoasi@sndkal.com', 'http://i.imgur.com/ClOuGSe.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_tokens`
--
ALTER TABLE `login_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `mealplan`
--
ALTER TABLE `mealplan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_tokens`
--
ALTER TABLE `password_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `login_tokens`
--
ALTER TABLE `login_tokens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `mealplan`
--
ALTER TABLE `mealplan`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `password_tokens`
--
ALTER TABLE `password_tokens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `login_tokens`
--
ALTER TABLE `login_tokens`
  ADD CONSTRAINT `login_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
